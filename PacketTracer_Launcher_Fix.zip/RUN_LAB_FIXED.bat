@echo off
setlocal EnableExtensions
title Cisco Packet Tracer Lab Launcher

set "LAB=%USERPROFILE%\Documents\PacketTracer\NetworkLab.pkt"
set "PT="

echo Searching for Cisco Packet Tracer...

REM 1. Try common install locations
for %%P in (
 "C:\Program Files\Cisco Packet Tracer\bin\PacketTracer.exe"
 "C:\Program Files (x86)\Cisco Packet Tracer\bin\PacketTracer.exe"
 "C:\Program Files\Cisco Packet Tracer\PacketTracer.exe"
 "C:\Program Files (x86)\Cisco Packet Tracer\PacketTracer.exe"
) do (
  if not defined PT if exist "%%~P" set "PT=%%~P"
)

REM 2. Ask PowerShell to inspect installed-app registry entries and Start Menu shortcuts
if not defined PT (
  for /f "usebackq delims=" %%I in (`powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='SilentlyContinue';" ^
    "$roots=@('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*');" ^
    "$apps=Get-ItemProperty $roots | Where-Object { $_.DisplayName -match 'Cisco Packet Tracer' };" ^
    "foreach($a in $apps){ $p=[Environment]::ExpandEnvironmentVariables([string]$a.InstallLocation); if($p){ foreach($f in @((Join-Path $p 'bin\PacketTracer.exe'),(Join-Path $p 'PacketTracer.exe'))){ if(Test-Path $f){Write-Output $f; exit} } }; $d=[string]$a.DisplayIcon; if($d){$d=$d.Trim('""'); $d=$d -replace ',\d+$',''; if(Test-Path $d){Write-Output $d; exit}} };" ^
    "$shell=New-Object -ComObject WScript.Shell;" ^
    "$dirs=@([Environment]::GetFolderPath('CommonPrograms'),[Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('CommonDesktopDirectory'));" ^
    "foreach($dir in $dirs){ if(Test-Path $dir){ Get-ChildItem $dir -Filter '*.lnk' -Recurse | ForEach-Object { $t=$shell.CreateShortcut($_.FullName).TargetPath; if($t -and (Split-Path $t -Leaf) -match '^PacketTracer\.exe$' -and (Test-Path $t)){Write-Output $t; exit} } } }"`) do (
      if not defined PT set "PT=%%I"
  )
)

REM 3. If automatic detection failed, let the user choose the executable
if not defined PT (
  echo Could not find PacketTracer.exe automatically.
  echo Select PacketTracer.exe in the file picker that opens.
  for /f "usebackq delims=" %%I in (`powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title='Locate Cisco Packet Tracer executable'; $d.Filter='PacketTracer.exe|PacketTracer.exe|Executable files (*.exe)|*.exe'; $d.FileName='PacketTracer.exe'; if($d.ShowDialog() -eq 'OK'){ $d.FileName }"`) do set "PT=%%I"
)

if not defined PT (
  echo.
  echo No executable selected. Nothing was launched.
  pause
  exit /b 1
)

if not exist "%PT%" (
  echo.
  echo The selected executable does not exist:
  echo "%PT%"
  pause
  exit /b 1
)

echo Found: "%PT%"

if exist "%LAB%" (
  echo Opening saved lab: "%LAB%"
  start "" "%PT%" "%LAB%"
) else (
  echo No saved lab found yet.
  echo Packet Tracer will open. Create your topology and save it as:
  echo "%LAB%"
  start "" "%PT%"
)

endlocal
