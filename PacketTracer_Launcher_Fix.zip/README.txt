FIXED PACKET TRACER LAUNCHER

1. Extract RUN_LAB_FIXED.bat somewhere convenient.
2. Double-click it.
3. It tries common install paths, installed-app registry entries, and Start Menu/Desktop shortcuts.
4. If it still cannot find Packet Tracer, a file picker opens. Browse to PacketTracer.exe and select it.
5. If you have not created NetworkLab.pkt yet, it simply opens Packet Tracer.

Typical executable locations include:
C:\Program Files\Cisco Packet Tracer\bin\PacketTracer.exe
C:\Program Files (x86)\Cisco Packet Tracer\bin\PacketTracer.exe

This launcher fixes executable discovery only. It does not create the Packet Tracer topology automatically.
