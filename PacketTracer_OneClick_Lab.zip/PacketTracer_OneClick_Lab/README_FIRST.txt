CISCO PACKET TRACER — ONE-CLICK LAB STARTER
===========================================

IMPORTANT LIMITATION
--------------------
Cisco Packet Tracer does not provide a supported command-line interface for
creating arbitrary .pkt topologies from scratch. This pack opens Packet Tracer
and supplies ready-to-paste IOS configurations, but it cannot safely create
and wire the GUI topology without GUI automation tailored to your Packet
Tracer version, screen resolution, and interface layout.

TOPOLOGY TO CREATE
------------------
Use Cisco 2811 routers, one 2960 switch, and one PC, matching your screenshot:
  R0 ----- R1 ----- R2 ----- R3
                   |
                 Switch
                   |
                   PC

Use the Serial DCE/DTE cable for router-to-router links where serial ports are
available. Use Copper Straight-Through for R2-to-switch and switch-to-PC.

ADDRESSING PLAN USED IN THIS PACK
---------------------------------
This is a clean, consistent example based on your notebook's 172.16.x.x
networks. It is an ASSUMPTION because the notebook photos do not unambiguously
show every router's interface-to-link mapping.

R0-R1 serial: 172.16.1.0/30  (R0 .1, R1 .2)
R1-R2 serial: 172.16.2.0/30  (R1 .1, R2 .2)
R2-R3 serial: 172.16.3.0/30  (R2 .1, R3 .2)
R0 LAN:       172.16.10.0/24 (R0 Fa0/0 = 172.16.10.1)
PC LAN:       172.16.30.0/24 (R2 Fa0/0 = 172.16.30.1; PC = .10)
R3 LAN:       172.16.40.0/24 (R3 Fa0/0 = 172.16.40.1)

If your instructor requires the exact notebook addressing, check the link
addresses and interface mapping before submitting. Do not mix /24 and /30
masks on the same link.

QUICK START
-----------
1. Extract this ZIP.
2. Open RUN_LAB.bat. If Packet Tracer is installed in a different location,
   edit the PT variable in that file.
3. In Packet Tracer, build the topology shown above and save it as:
   %USERPROFILE%\\Documents\\PacketTracer\\NetworkLab.pkt
4. Open each router's CLI and paste the matching file from router_configs.
5. Set the PC Desktop > IP Configuration values shown in PC_SETTINGS.txt.
6. Test pings and save the .pkt file.

ROUTER CONFIGURATION NOTES
--------------------------
- Router model: Cisco 2811.
- The configs use Serial0/0/0 and, on some routers, Serial0/0/1. If your router
  does not show those interfaces, power it off, add a WIC-2T module if
  supported, then power it on. Interface names may vary by module/model.
- On the serial end connected to the DCE cable, enter:
      clock rate 64000
  only if Packet Tracer identifies that end as DCE.
- Paste configs only after the corresponding cables and interfaces exist.
- If an interface name differs, edit the config to match the actual interface.

Verification commands:
  show ip interface brief
  show ip route
  ping 172.16.30.10
  ping 172.16.10.1
  copy running-config startup-config

This pack intentionally does not claim the .pkt topology has been generated:
the .pkt file is a Packet Tracer-specific binary project format.
