@echo off
setlocal
set "PT1=C:\Program Files\Cisco Packet Tracer\bin\PacketTracer.exe"
set "PT2=C:\Program Files (x86)\Cisco Packet Tracer\bin\PacketTracer.exe"
set "LAB=%USERPROFILE%\Documents\PacketTracer\NetworkLab.pkt"

if exist "%PT1%" (
  set "PT=%PT1%"
) else if exist "%PT2%" (
  set "PT=%PT2%"
) else (
  echo Packet Tracer executable not found in the usual locations.
  echo Edit PT1 or PT2 in this file to match your installation.
  pause
  exit /b 1
)

if not exist "%LAB%" (
  echo No saved lab exists yet.
  echo Create the topology in Packet Tracer and save it as:
  echo %LAB%
  start "" "%PT%"
  pause
  exit /b 0
)

start "" "%PT%" "%LAB%"
endlocal
